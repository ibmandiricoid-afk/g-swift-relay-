const nodemailer = require('nodemailer');
exports.handler = async (event) => {
  const headers = {"Content-Type":"application/json","Access-Control-Allow-Origin":"*"};
  try {
    const { to, subject, html, text, smtp } = JSON.parse(event.body||'{}');
    if (!smtp?.user || !smtp?.pass) {
      return {statusCode:400, headers, body:JSON.stringify({error:'Isi username & App Password dulu di menu AKUN'})};
    }
    const transporter = nodemailer.createTransport({
      host: smtp.host||'smtp.gmail.com',
      port: Number(smtp.port)||587,
      secure: Number(smtp.port)===465,
      auth:{user:smtp.user, pass:smtp.pass}
    });
    if (!to) {
      await transporter.verify();
      return {statusCode:200, headers, body:JSON.stringify({success:true, message:'SMTP OK'})};
    }
    await transporter.sendMail({
      from:`"${smtp.fromName||'Relay'}" <${smtp.user}>`,
      to, subject:subject||'(test)', text:text||'test', html:html||'<p>test</p>'
    });
    return {statusCode:200, headers, body:JSON.stringify({success:true})};
  } catch(e){
    return {statusCode:500, headers, body:JSON.stringify({error:e.message})};
  }
};
