exports.handler = async () => {
  return {
    statusCode: 200,
    headers: {"Content-Type":"application/json","Access-Control-Allow-Origin":"*"},
    body: JSON.stringify({
      status: "ok",
      relay: "active",
      message: "G-Swift Relay active. System ready.",
      timestamp: new Date().toISOString()
    })
  };
};
