export async function handler(event, context) {
  return {
    statusCode: 200,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*"
    },
    body: JSON.stringify({
      status: "ok",
      service: "server pengiriman email cepat",
      time: new Date().toISOString()
    })
  };
}
