const nodemailer = require("nodemailer");

exports.handler = async function(event) {
  // CORS preflight
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "POST, OPTIONS"
      },
      body: ""
    };
  }

  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }

  try {
    const { to, subject, text, html, from } = JSON.parse(event.body || "{}");

    if (!to || !subject || (!text && !html)) {
      return {
        statusCode: 400,
        headers: { "Access-Control-Allow-Origin": "*" },
        body: JSON.stringify({ error: "to, subject, dan text/html wajib diisi" })
      };
    }

    const transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST, // smtp.office365.com
      port: Number(process.env.SMTP_PORT || 587),
      secure: Number(process.env.SMTP_PORT) === 465,
      auth: {
        user: process.env.SMTP_USER, // nama@outlook.co.id
        pass: process.env.SMTP_PASS
      },
      tls: { ciphers: 'SSLv3' } // penting untuk Outlook
    });

    const info = await transporter.sendMail({
      from: from || process.env.SMTP_FROM || process.env.SMTP_USER, // <-- pastikan SMTP_FROM = "Nama Toko <email@outlook.co.id>"
      to,
      subject,
      text,
      html
    });

    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      },
      body: JSON.stringify({
        success: true,
        messageId: info.messageId,
        accepted: info.accepted
      })
    };
  } catch (err) {
    return {
      statusCode: 500,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ error: err.message })
    };
  }
};